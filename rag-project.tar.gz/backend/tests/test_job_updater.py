from __future__ import annotations

import unittest
import uuid

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend.app.database import Base
from backend.app.ingest.job_updater import JobUpdater
from backend.app.models import DocumentRecord, IngestJob


class JobUpdaterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(self.engine)
        self.session = sessionmaker(bind=self.engine)()

        self.document = DocumentRecord(
            id=str(uuid.uuid4()),
            filename="test.pdf",
            object_key="test/test.pdf",
            mime_type="application/pdf",
            size_bytes=123,
        )
        self.session.add(self.document)
        self.session.commit()

        self.job = IngestJob(
            id=str(uuid.uuid4()),
            document_id=self.document.id,
            status="queued",
            stage="fetching_object",
            progress_pct=0,
            pipeline_version="1.0.0",
        )
        self.session.add(self.job)
        self.session.commit()

    def tearDown(self) -> None:
        self.session.close()
        self.engine.dispose()

    def test_progress_is_monotonic(self) -> None:
        updater = JobUpdater(self.session)

        updater.set_state(self.job.id, status="running", stage="parsing", progress_pct=30)
        job = updater.set_state(self.job.id, progress_pct=10)

        self.assertEqual(job.progress_pct, 30)
        self.assertEqual(job.status, "running")

    def test_rejects_backward_stage(self) -> None:
        updater = JobUpdater(self.session)

        updater.set_state(self.job.id, stage="embedding")
        with self.assertRaises(ValueError):
            updater.set_state(self.job.id, stage="parsing")

    def test_fail_writes_terminal_fields(self) -> None:
        updater = JobUpdater(self.session)

        failed = updater.fail(self.job.id, "parser exploded")

        self.assertEqual(failed.status, "failed")
        self.assertEqual(failed.stage_detail, "ingest_failed")
        self.assertIn("parser exploded", failed.error_message)
        self.assertIsNotNone(failed.finished_at)


if __name__ == "__main__":
    unittest.main()
